function act= PN_s2act(MP)

% Create 4x3-keyboard column actuation
%
% MP:  1xN : marked places (integer values >= 0)
% act: 1x3 : column actuation values (0 or 1 per entry)

%error('function NOT implemented')

act = [0 0 0];

if MP(1) == 1 || ~isempty(nonzeros(MP(4:7))) 
   act = [ 1 0 0];

elseif MP(2) == 1 || ~isempty(nonzeros(MP(8:11)))
   act = [ 0 1 0];

elseif MP(3) == 1 || ~isempty(nonzeros(MP(12:15)))
   act = [ 0 0 1];
end

return