
function waitkey(i)

if nargin < 1, i = 0; end

if i ~= 1
   disp('Press any key to continue')
   pause
end
