function act= PN_s2act(MP)
% all places output 0
act = [0 0 0];

if MP(1) == 1 || ~isempty(nonzeros(MP(4:7))) 
   act = [ 1 0 0];

elseif MP(2) == 1 || ~isempty(nonzeros(MP(8:11)))
   act = [ 0 1 0];

elseif MP(3) == 1 || ~isempty(nonzeros(MP(12:15)))
   act = [ 0 0 1];
end
