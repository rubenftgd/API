function yout= PN_s2yout(MP)
% simply copy the state
% yout= MP(:)';
yout = zeros(1,13);

if MP(4) == 1
    yout(1+1) = 1;
elseif MP(5) == 1
    yout(4+1) = 1;
elseif MP(6) == 1
    yout(7+1) = 1;
elseif MP(7) == 1
    yout(10+1) = 1;
elseif MP(8) == 1
    yout(2+1) = 1;
elseif MP(9) == 1
    yout(5+1) = 1;
elseif MP(10) == 1
    yout(8+1) = 1;
elseif MP(11) == 1
    yout(0+1) = 1;
elseif MP(12) == 1
    yout(3+1) = 1;
elseif MP(13) == 1
    yout(6+1) = 1;
elseif MP(14) == 1
    yout(9+1) = 1;
elseif MP(15) == 1
    yout(11+1) = 1;
elseif MP(17) == 1
    yout(12+1) = 1;
end