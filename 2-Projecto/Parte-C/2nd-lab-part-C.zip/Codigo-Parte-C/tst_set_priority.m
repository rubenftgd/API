function tst_set_priority

close all
clear all
clc

% incidence matrix
% D= [-1 +1 -1 +1
%     +1 -1  0  0
%     +0  0 +1 -1];
% Pre = -D.*(D<0);
% Post=  D.*(D>0);

% initial marking
% M0  = [1 0 0]';

[Pre,Post,M0] = rdp('petri_supervisor.xml');

% simulation time [ini, end, delta]
ti_tf= [0 10 1e-2];

% run two simulations
[t1, M1, yout1,linesSav,qk]= PN_sim(Pre, Post, M0, ti_tf, []);
[t2, M2, yout2,linesSav2,qk2]= PN_sim(Pre, Post, M0, ti_tf, struct('tprio',[28]));

% display results
figure(201)%, clf;
% subplot(311); %PN_tfire; % show input data
subplot(321)
    plot_z(t1, qk,'-');ylabel('Transitions fired (no priority)'); xlabel('time [sec]');
    ylim([0 30.5]);
subplot(322)
    plot_z(t2, qk2,'-');ylabel('Transitions fired (priority)'); xlabel('time [sec]');
    ylim([0 30.5]);
subplot(323);
    plot_z(t1,M1,'-'); ylabel('place marking (no priority)'); xlabel('time [sec]');
    ylim([0 30]);
subplot(324)
    plot_z(t2,M2,'-'); ylabel('place marking (priority)'); xlabel('time [sec]');
    ylim([0 30]);
subplot(325)
    plot_z(t1,yout1,'-'); ylabel('detected keys (no priority)'); xlabel('time [sec]');
    yticks([1 2:2:10 11:12 13]);
    aux = yticks;
    ytick_legends = {'0','1','3','5','7','9','*','#','ERR'};
    yticklabels(ytick_legends);
    ylim([0 14]);
subplot(326)
    plot_z(t2,yout2,'-'); ylabel('detected keys (priority)'); xlabel('time [sec]');
    yticks([1 2:2:10 11:12 13]);
    aux = yticks;
    ytick_legends = {'0','1','3','5','7','9','*','#','ERR'};
    yticklabels(ytick_legends);
    ylim([0 14]);
    
figure(202)
% subplot(221)
%     plot_z(t1,M1,'-'); ylabel('place marking (no priority)'); xlabel('time [sec]');
%     ylim([0 30]);
subplot(211)
    plot_z(t2,M2,'-'); ylabel('place marking (priority)'); xlabel('time [sec]');
    ylim([0 30]);
% subplot(211)
%     plot_z(t1,yout1,'-'); ylabel('detected keys (no priority)'); xlabel('time [sec]');
%     yticks([1 2:2:10 11:12 13]);
%     aux = yticks;
%     ytick_legends = {'0','1','3','5','7','9','*','#','ERR'};
%     yticklabels(ytick_legends);
%     ylim([0 14]);
subplot(212)
    plot_z(t2,yout2,'-'); ylabel('detected keys (priority)'); xlabel('time [sec]');
    yticks([1 2:2:10 11:12 13]);
    aux = yticks;
    ytick_legends = {'0','1','3','5','7','9','*','#','ERR'};
    yticklabels(ytick_legends);
    ylim([0 14]);
    
figure(203)%, clf;
% subplot(311); %PN_tfire; % show input data
subplot(211)
    plot_z(t1, qk,'-');ylabel('Transitions fired (no priority)'); xlabel('time [sec]');
    ylim([0 30]);
subplot(212)
    plot_z(t2, qk2,'-');ylabel('Transitions fired (priority)'); xlabel('time [sec]');
    ylim([0 30]);

figure(200)
    PN_device_kb_IO
    
figure(300), clf;
        subplot(221); PN_device_kb_IO; % show input data
        subplot(222)
            plot_z(t2, qk2,'-');ylabel('Transitions fired'); xlabel('time [sec]');
            ylim([0 30]);
        subplot(223); plot_z(t2,M2,'-'); ylabel('place number'); xlabel('time [sec]');
        subplot(224); plot_z(t2,yout2,'-'); ylabel('key number'); xlabel('time [sec]');
            yticks([1 2:2:10 11:12 13]);
            aux = yticks;
            ytick_legends = {'0','1','3','5','7','9','*','#','ERR'};
            yticklabels(ytick_legends);
            ylim([0 14]);
            
figure()
    plot_z(t2,linesSav2(:,1:4));
    ylabel('lines pressed');
figure()
    plot(t2, linesSav2(:,5));
    ylabel('#lines pressed');
end