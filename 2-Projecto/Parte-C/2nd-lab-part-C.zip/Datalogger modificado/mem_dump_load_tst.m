% Load and plot Unity memory dumps (datalogging)
% Original version by JG (2014?)
% 
% with bugfixes by Jo�o Ribafeita(75987, joao.ribafeita@tecnico.ulisboa.pt)
% with multicolor plotting option for patches and automatic legend
% insertion
% With UI for choosing files and legend data

% CELL ARRAY for LEGEND

function mem_dump_load_tst(tstId)
if nargin<1
    tstId= 1;
end

switch tstId
    case 1
        aux=inputdlg({'Please input the number of bits you have logged:'},...
                      'Input',1,{'16'});
        if isempty(aux)
            error('Insert the number of bits you have logged')
        end
        n_bits = str2num(aux{1});
        %         fname= 'ativo_dp.DTX';
        fname = uigetfile('*.DTX','Please select the dump (DTX) file to load...');
        if fname == 0
            error('Please select a .DTX file to load');
        end
        %  LEGENDA A USAR
        for i = 1:n_bits
            if i ==1
                bits_used = {'Bit 1'};
            else
                bits_used(end+1) = {sprintf('Bit %d name',i)};
            end
        end
        legends=inputdlg(bits_used,'Legend',1);
        if isempty(legends)
            error('Please provide legend details');
        end
        x= mem_dump_load( fname );
        %  insert zero time in the beginning (correcting the connection of
        %  the dots), implying initial state (eg, plc boot, ...)
%         x = horzcat([0;0],x);
        %  truncate x vector, to remove 0's in the end; this eliminates
        %  plotting errors; useful when logging many events and vector is
        %  not full, thereby resulting in plotting mistakes
        x = x(:,1:find(x(1,:),1,'last'));
        figure(201); clf;
        stairs(x(1,:), x(2,:), '.-', 'linewidth',4)
        xlabel('scan cycle number')
        ylabel('16bits word as decimal')
        
        figure(202); clf;
        %         z= dec2bin(x(2,:),16)-'0'; z= z(:,end:-1:1);
        z= dec2bin(x(2,:),16)-'0'; z= z(:,end:-1:1);
        %plot_z(x(1,:), z)
        %plot_z(x(1,:), z, struct('patch',1))
        %  Added coloring option
        plot_z(x(1,:), z(:,1:n_bits), struct('patch',1,'zoh',1,'multicolor',1))
        xlabel('scan cycle number')
        ylabel('bit number')
        %  added legend
        legend(legends,'orientation','vertical','location','eastoutside',...
               'Interpreter', 'none');
    otherwise
        error('inv tstId')
end

return
