function yout= PN_s2yout(MP)

% Show the detected/undetected key(s) given the Petri state
%
% MP: 1xN : marked places (integer values >= 0)

if MP(4) == 1
    yout = 1;
elseif MP(5) == 1
    yout = 4;
elseif MP(6) == 1
    yout = 7;
elseif MP(7) == 1
    yout = 10;
elseif MP(8) == 1
    yout = 2;
elseif MP(9) == 1
    yout = 5;
elseif MP(10) == 1
    yout = 8;
elseif MP(11) == 1
    yout = 0;
elseif MP(12) == 1
    yout = 3;
elseif MP(13) == 1
    yout = 6;
elseif MP(14) == 1
    yout = 9;
elseif MP(15) == 1
    yout = 11;
else
    yout = -1;
end
    