function P= vector_permute( n, idx )
% usage example: q= (1:5)'; P= vector_permute( [1 4 2], 5 ); P*q
P= eye(n);
P= P( [idx setdiff(1:n, idx)], : );