function tst_set_priority

% incidence matrix
% D= [-1 +1 -1 +1
%     +1 -1  0  0
%     +0  0 +1 -1];
% Pre = -D.*(D<0);
% Post=  D.*(D>0);

% initial marking
% M0  = [1 0 0]';

[Pre,Post,M0] = rdp('petri.xml');

% simulation time [ini, end, delta]
ti_tf= [0 10 1e-2];

% run two simulations
[t1, M1, yout1,linesSav,qk]= PN_sim(Pre, Post, M0, ti_tf, []);
[t2, M2, yout2,linesSav2,qk2]= PN_sim(Pre, Post, M0, ti_tf, struct('tprio',[15]));

% display results
figure(201)%, clf;
% subplot(311); %PN_tfire; % show input data
subplot(321)
    plot_z(t1, qk,'-');ylabel('Transitions fired (no priority)'); xlabel('time [sec]');
    ylim([0 28]);
subplot(322)
    plot_z(t2, qk2,'-');ylabel('Transitions fired (priority)'); xlabel('time [sec]');
    ylim([0 28]);
subplot(323);
    plot_z(t1,M1,'-'); ylabel('place marking (no priority)'); xlabel('time [sec]');
    ylim([0 16]);
subplot(324)
    plot_z(t2,M2,'-'); ylabel('place marking (priority)'); xlabel('time [sec]');
    ylim([0 16]);
subplot(325)
    plot_z(t1,yout1,'-'); ylabel('detected keys (no priority)'); xlabel('time [sec]');
    yticks([1 2:2:10 11:12]);
    aux = yticks;
    ytick_legends = {'0','1','3','5','7','9','*','#'};
    yticklabels(ytick_legends);
    ylim([0 12.6]);
subplot(326)
    plot_z(t2,yout2,'-'); ylabel('detected keys (priority)'); xlabel('time [sec]');
    yticks([1 2:2:10 11:12]);
    aux = yticks;
    ytick_legends = {'0','1','3','5','7','9','*','#'};
    yticklabels(ytick_legends);
    ylim([0 12.6]);
    
figure(202)
subplot(221)
    plot_z(t1,M1,'-'); ylabel('place marking (no priority)'); xlabel('time [sec]');
    ylim([0 16]);
subplot(222)
    plot_z(t2,M2,'-'); ylabel('place marking (priority)'); xlabel('time [sec]');
    ylim([0 16]);
subplot(223)
    plot_z(t1,yout1,'-'); ylabel('detected keys (no priority)'); xlabel('time [sec]');
    yticks([1 2:2:10 11:12]);
    aux = yticks;
    ytick_legends = {'0','1','3','5','7','9','*','#'};
    yticklabels(ytick_legends);
    ylim([0 12.6]);
subplot(224)
    plot_z(t2,yout2,'-'); ylabel('detected keys (priority)'); xlabel('time [sec]');
    yticks([1 2:2:10 11:12]);
    aux = yticks;
    ytick_legends = {'0','1','3','5','7','9','*','#'};
    yticklabels(ytick_legends);
    ylim([0 12.6]);
    
figure(203)%, clf;
% subplot(311); %PN_tfire; % show input data
subplot(211)
    plot_z(t1, qk,'-');ylabel('Transitions fired (no priority)'); xlabel('time [sec]');
    ylim([0 28]);
subplot(212)
    plot_z(t2, qk2,'-');ylabel('Transitions fired (priority)'); xlabel('time [sec]');
    ylim([0 28]);    

figure(200)
    PN_device_kb_IO