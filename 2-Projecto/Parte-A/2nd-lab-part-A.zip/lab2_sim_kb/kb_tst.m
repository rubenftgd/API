% Original by Professor J. Gaspar
% May2019, some modifications by Jo�o Ribafeita [joao.ribafeita@tecnico.ulisboa.pt]
function kb_tst(tstId)
if nargin<1
    tstId= 2;
end

% global keys_pressed;
% keys_pressed = []

switch tstId
    case 2
        if ~exist('petri.xml', 'file')
		    error('please create your Petri net and save it as file "petri.xml"');
		end
		[Pre, Post, M0] = rdp('petri.xml');
%         D_test = Post-Pre
        [t, M, yout,qin,ik,qk]= PN_sim(Pre, Post, M0, [0 10]);
        
        for i = 1:length(t)
            lines(i,:) = PN_device_kb_IO(ik(i,:),t(i));
        end
        

        figure(201), clf;
        subplot(221); PN_device_kb_IO % show input data
        % JR, plot with pressed lines, global integration
        subplot(222); plot_z(t,lines,'-');xlabel('time [sec]'); ylabel('lines pressed');
        subplot(223); plot_z(t,M,'-'); ylabel('place number'); xlabel('time [sec]');
        subplot(224); plot_z(t,yout,'-'); ylabel('key number'); xlabel('time [sec]');

    otherwise
        error('invalid tstId')
end

return
