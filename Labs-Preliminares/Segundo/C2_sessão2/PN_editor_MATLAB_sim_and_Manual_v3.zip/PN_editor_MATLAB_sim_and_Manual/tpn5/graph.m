function [A,RM] = graph(Pre,Post,M0)
% function name graph.m cannot be used in Matlab 2016
% please use instead graph2.m
[A,RM] = graph2(Pre,Post,M0);
