function part_c_v0

% 1. put the compiler in the path (already added to path...)
% path(path,'../pn_to_plc_compiler')

% 2. choose one of the two hardware setups available in the lab
% plc_z_code_helper('config'); % ask hardware config
plc_z_code_helper('config_get'); % do not ask if saved before

% 3. the compiler just needs PN, input_map, output_map
PN= define_petri_net;
input_map= define_input_mapping;
output_map= define_output_mapping;

% 4. from here it is automatic
ofname= 'tst1_mk_program_res.txt';
plc_make_program( ofname, PN, input_map, output_map )

return; % end of main program


function PN= define_petri_net

% Define the Petri Net
%  write incidence matrix D by columns (and transpose it)
%  get "pre" (D-) from negative entries of D
%  get "pos" (D+) from positive entries of D
%  define initial marking "mu0"


% D=[ -1     0     1    -1     1     0     0     0     0
%      1    -1     0     0     0    -1     1     0     0
%      0     1    -1     0     0     0     0    -1     1
%      0     0     0     1    -1     0     0     0     0
%      0     0     0     0     0     1    -1     0     0
%      0     0     0     0     0     0     0     1    -1];
% pre= -D.*(D<0);
% pos=  D.*(D>0);
% mu0= [1 0 0 0 0 0]';
[pre,pos,mu0] = rdp('petri_supervisor.xml');

% define priority transitions (empty indicates no specific priorities)
tprio= [28];

% 0.5 seconds timeout from places p1, p2 and p3 to transitions t1 t2 t3
T= 0.25;
ttimed= [T 1 1; T 2 2; T 3 3]; % column2=place, column3=transition

% output structure
PN= struct('pre',pre, 'pos',pos, 'mu0',mu0, 'tprio',tprio, 'ttimed',ttimed);


% function inp_map= define_input_mapping
% inp_map= { ...
%     0,        4 ; ... % input0 fires transition4
%     -(0+100), 5 ; ... % negative input0 fires t5
%     };

function inp_map= define_input_mapping
inp_map= { ...
    % tecla 1
    4,        4 ; ... % input0 fires transition4
    -(4+100), 16 ; ... % negative input0 fires t
    % tecla 2
    4,        8 ; ... % input0 fires transition6
    -(4+100), 20 ; ... % negative input0 fires t
    % tecla 3
    4,        12 ; ... % input0 fires transition8
    -(4+100), 24 ; ... % negative input0 fires t
    % tecla 4
    5,        5 ; ... % input0 fires transition4
    -(5+100), 17 ; ... % negative input0 fires t
    % tecla 5
    5,        9 ; ... % input0 fires transition6
    -(5+100), 21 ; ... % negative input0 fires t
    % tecla 6
    5,        13 ; ... % input0 fires transition8
    -(5+100), 25 ; ... % negative input0 fires t
    % tecla 7
    6,        6 ; ... % input0 fires transition4
    -(6+100), 18 ; ... % negative input0 fires t
    % tecla 8
    6,        10 ; ... % input0 fires transition6
    -(6+100), 22 ; ... % negative input0 fires t
    % tecla 9
    6,        14 ; ... % input0 fires transition8
    -(6+100), 26 ; ... % negative input0 fires t
    % tecla *
    7,        7 ; ... % input0 fires transition4
    -(7+100), 19 ; ... % negative input0 fires t
    % tecla 0
    7,        11 ; ... % input0 fires transition6
    -(7+100), 23 ; ... % negative input0 fires t
    % tecla #
    7,        15 ; ... % input0 fires transition8
    -(7+100), 27 ; ... % negative input0 fires t
    % dummy one, for error transition
    15,        28 ; ... % input0 fires transition8
    -(15+100), 29 ; ... % negative input0 fires t
    };



function output_map= define_output_mapping
% map PN places 1..3 to the first output bits
zCode= plc_z_code_helper('config_get');
output_map= { ...
    % q0.4.4-->q0.4.6
    1, zCode.outpMin+4 ; ...
    2, zCode.outpMin+5 ; ...
    3, zCode.outpMin+6; ...
%     3, zCode.outpMin+2 ;
%     4, zCode.outpMin+1; zCode.outpMin+2; zCode.outpMin+3;
%     detec��o de teclas (1,2,3)
    16, zCode.outpMin+1; ...
    17, zCode.outpMin+3; ...
    };
