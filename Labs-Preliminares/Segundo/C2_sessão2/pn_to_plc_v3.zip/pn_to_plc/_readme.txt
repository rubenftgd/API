
Folder ./pn_to_plc_compiler/. contains the compiler

Folder ./tst1_blink_turn_on_off/. contains a demo

To make the structured text code (Matlab) cd to folder and run:
>> tst1_blink_on_off
To test the generated structured text code, paste it in a Unity section.

Note: ./tst0_timed_outputs/. contains also a demo illustrating timers & output, but
./tst1_blink_turn_on_off/. is more complete as it contains also inputs
