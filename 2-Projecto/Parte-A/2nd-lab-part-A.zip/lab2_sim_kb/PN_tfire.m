function qk= PN_tfire(act, t)

% Possible-to-fire transitions given PN outputs (act) and the time t
%
% act: 1xN : PN outputs (PLC outputs) 
% t  : 1x1 : time
% qk : 1xM : possible firing vector (to be filtered later with enabled
%            transitions)

aux1 = round(rand (1,1));
aux2 = round(rand (1,4));
aux3 = round(rand (1,4));

% qk= ([aux1 not(aux1) not(aux1) aux2 not(aux2) not(aux2) aux3 not(aux3) not(aux3)]>0.5);
qk = round(rand (27,1));
%qk= [qk  not(qk)];

end
